import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { usePostingStatus } from "@/hooks/use-posting-status";
import { PostingRulesBanner } from "@/components/PostingRulesBanner";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ImagePlus, X, Loader2, Video } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export default function CreatePost() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const { data: postingStatus } = usePostingStatus();
  const [caption, setCaption] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []).slice(0, 4);
    setFiles(prev => [...prev, ...selected].slice(0, 4));
    setPreviews(prev => [...prev, ...selected.map(f => URL.createObjectURL(f))].slice(0, 4));
  };

  const removeFile = (idx: number) => {
    setFiles(f => f.filter((_, i) => i !== idx));
    setPreviews(p => p.filter((_, i) => i !== idx));
  };

  const handleSubmit = async () => {
    if (!user || (!caption.trim() && files.length === 0)) return;
    if (postingStatus && !postingStatus.allowed) { toast.error("You've reached your daily post limit"); return; }
    setSubmitting(true);

    try {
      const { data: post, error } = await supabase.from("posts").insert({ author_id: user.id, caption: caption.trim() || null }).select().single();
      if (error) throw error;

      for (const file of files) {
        const ext = file.name.split(".").pop();
        const path = `${user.id}/posts/${post.id}/${crypto.randomUUID()}.${ext}`;
        await supabase.storage.from("media").upload(path, file);
        const { data: urlData } = supabase.storage.from("media").getPublicUrl(path);
        const isVideo = file.type.startsWith("video/");
        await supabase.from("media").insert({ post_id: post.id, url: urlData.publicUrl, type: isVideo ? "VIDEO" : "IMAGE" });
      }

      queryClient.invalidateQueries({ queryKey: ["posts"] });
      toast.success("Post created!");
      navigate("/");
    } catch {
      toast.error("Failed to create post");
    }
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <PostingRulesBanner />
        <Card className="border-0 shadow-sm">
          <CardHeader><CardTitle>Create Post</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Textarea value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="What's on your mind?" maxLength={500} rows={4} className="rounded-xl resize-none border-0 bg-muted/30 focus-visible:ring-primary/30" />

            {previews.length > 0 && (
              <div className="grid grid-cols-2 gap-2">
                {previews.map((p, i) => (
                  <div key={i} className="relative rounded-xl overflow-hidden">
                    {files[i]?.type.startsWith("video/") ? (
                      <video src={p} className="h-40 w-full object-cover" />
                    ) : (
                      <img src={p} alt="" className="h-40 w-full object-cover" />
                    )}
                    <Button variant="destructive" size="icon" className="absolute right-1 top-1 h-6 w-6 rounded-full" onClick={() => removeFile(i)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={files.length >= 4} className="rounded-xl gap-1.5">
                <ImagePlus className="h-4 w-4" /> Photo
              </Button>
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={files.length >= 4} className="rounded-xl gap-1.5">
                <Video className="h-4 w-4" /> Video
              </Button>
              <input ref={fileRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={handleFileChange} />
              <div className="flex-1" />
              <Button onClick={handleSubmit} disabled={submitting || (!caption.trim() && files.length === 0)} className="rounded-xl gradient-primary border-0">
                {submitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Posting...</> : "Post"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
      <BottomNav />
    </div>
  );
}
