import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Search, UserCheck, UserX, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Friends() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: friendships = [], isLoading } = useQuery({
    queryKey: ["friendships", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from("friendships")
        .select("*, requester:profiles!friendships_requester_id_fkey(*), addressee:profiles!friendships_addressee_id_fkey(*)")
        .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`)
        .order("updated_at", { ascending: false });
      return data || [];
    },
    enabled: !!user,
  });

  const accepted = friendships.filter((f: any) => f.status === "ACCEPTED");
  const incoming = friendships.filter((f: any) => f.status === "REQUESTED" && f.addressee_id === user?.id);
  const outgoing = friendships.filter((f: any) => f.status === "REQUESTED" && f.requester_id === user?.id);

  const handleAccept = async (id: string) => {
    await supabase.from("friendships").update({ status: "ACCEPTED" }).eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["friendships"] });
    queryClient.invalidateQueries({ queryKey: ["pending-request-count"] });
    toast.success("Friend request accepted!");
  };

  const handleReject = async (id: string) => {
    await supabase.from("friendships").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["friendships"] });
    queryClient.invalidateQueries({ queryKey: ["pending-request-count"] });
  };

  const getFriend = (f: any) => f.requester_id === user?.id ? f.addressee : f.requester;

  const filterBySearch = (list: any[]) =>
    search ? list.filter((f: any) => {
      const friend = getFriend(f);
      return friend?.display_name?.toLowerCase().includes(search.toLowerCase()) || friend?.username?.toLowerCase().includes(search.toLowerCase());
    }) : list;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <h1 className="mb-4 text-2xl font-bold">Friends</h1>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search friends..." className="pl-9 rounded-xl" />
        </div>

        <Tabs defaultValue={incoming.length > 0 ? "requests" : "friends"}>
          <TabsList className="w-full rounded-xl mb-4">
            <TabsTrigger value="friends" className="flex-1 rounded-lg">Friends ({accepted.length})</TabsTrigger>
            <TabsTrigger value="requests" className="flex-1 rounded-lg relative">
              Requests
              {incoming.length > 0 && <span className="ml-1.5 inline-flex h-5 min-w-5 items-center justify-center rounded-full gradient-primary text-[10px] text-primary-foreground px-1">{incoming.length}</span>}
            </TabsTrigger>
            <TabsTrigger value="sent" className="flex-1 rounded-lg">Sent ({outgoing.length})</TabsTrigger>
          </TabsList>

          {isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
          ) : (
            <>
              <TabsContent value="friends">
                {filterBySearch(accepted).length === 0 ? (
                  <div className="py-12 text-center"><Users className="mx-auto mb-3 h-12 w-12 text-muted-foreground/30" /><p className="text-muted-foreground">No friends yet</p></div>
                ) : (
                  <div className="space-y-2">
                    {filterBySearch(accepted).map((f: any) => {
                      const friend = getFriend(f);
                      return (
                        <Link key={f.id} to={`/profile/${friend.username}`}>
                          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
                            <CardContent className="flex items-center gap-3 p-3">
                              <Avatar className="h-12 w-12"><AvatarImage src={friend.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground font-bold">{friend.display_name?.[0]}</AvatarFallback></Avatar>
                              <div className="min-w-0 flex-1">
                                <p className="truncate font-semibold text-sm">{friend.display_name}</p>
                                <p className="truncate text-xs text-muted-foreground">@{friend.username}</p>
                              </div>
                            </CardContent>
                          </Card>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="requests">
                {incoming.length === 0 ? (
                  <div className="py-12 text-center text-muted-foreground">No pending requests</div>
                ) : (
                  <div className="space-y-2">
                    {incoming.map((f: any) => (
                      <Card key={f.id} className="border-0 shadow-sm animate-fade-in-up">
                        <CardContent className="flex items-center gap-3 p-3">
                          <Avatar className="h-12 w-12"><AvatarImage src={f.requester.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground font-bold">{f.requester.display_name?.[0]}</AvatarFallback></Avatar>
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-semibold text-sm">{f.requester.display_name}</p>
                            <p className="truncate text-xs text-muted-foreground">@{f.requester.username}</p>
                          </div>
                          <div className="flex gap-1.5">
                            <Button size="sm" onClick={() => handleAccept(f.id)} className="gradient-primary border-0 rounded-xl gap-1"><UserCheck className="h-3.5 w-3.5" /> Accept</Button>
                            <Button size="sm" variant="outline" onClick={() => handleReject(f.id)} className="rounded-xl"><UserX className="h-3.5 w-3.5" /></Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="sent">
                {outgoing.length === 0 ? (
                  <div className="py-12 text-center text-muted-foreground">No sent requests</div>
                ) : (
                  <div className="space-y-2">
                    {outgoing.map((f: any) => (
                      <Card key={f.id} className="border-0 shadow-sm">
                        <CardContent className="flex items-center gap-3 p-3">
                          <Avatar className="h-12 w-12"><AvatarImage src={f.addressee.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground font-bold">{f.addressee.display_name?.[0]}</AvatarFallback></Avatar>
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-semibold text-sm">{f.addressee.display_name}</p>
                            <p className="truncate text-xs text-muted-foreground">@{f.addressee.username}</p>
                          </div>
                          <Button size="sm" variant="outline" onClick={() => handleReject(f.id)} className="rounded-xl text-muted-foreground">Cancel</Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </>
          )}
        </Tabs>
      </main>
      <BottomNav />
    </div>
  );
}
