import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Loader2, Send } from "lucide-react";
import { format, differenceInMinutes } from "date-fns";
import { cn } from "@/lib/utils";

export default function Conversation() {
  const { conversationId: partnerId } = useParams<{ conversationId: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: partner } = useQuery({
    queryKey: ["profile-by-id", partnerId],
    queryFn: async () => { const { data } = await supabase.from("profiles").select("*").eq("user_id", partnerId!).single(); return data; },
    enabled: !!partnerId,
  });

  const isOnline = partner?.last_seen ? differenceInMinutes(new Date(), new Date(partner.last_seen)) < 2 : false;

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages", user?.id, partnerId],
    queryFn: async () => {
      if (!user || !partnerId) return [];
      const { data } = await supabase.from("messages").select("*")
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${user.id})`)
        .order("created_at", { ascending: true });
      return data || [];
    },
    enabled: !!user && !!partnerId,
  });

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length]);

  useEffect(() => {
    if (!user || !partnerId) return;
    const channel = supabase.channel(`conv-${partnerId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, () => {
        queryClient.invalidateQueries({ queryKey: ["messages", user.id, partnerId] });
      }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, partnerId, queryClient]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user || !partnerId) return;
    setSending(true);
    await supabase.from("messages").insert({ sender_id: user.id, receiver_id: partnerId, body: message.trim() });
    setMessage("");
    queryClient.invalidateQueries({ queryKey: ["messages", user.id, partnerId] });
    setSending(false);
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <Link to="/messages"><ArrowLeft className="h-5 w-5" /></Link>
        {partner && (
          <div className="flex items-center gap-2">
            <div className="relative">
              <Avatar className="h-9 w-9"><AvatarImage src={partner.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground text-xs font-bold">{partner.display_name?.[0]}</AvatarFallback></Avatar>
              {isOnline && <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-background bg-green-500" />}
            </div>
            <div><p className="text-sm font-semibold">{partner.display_name}</p><p className="text-[11px] text-muted-foreground">{isOnline ? "Online" : "Offline"}</p></div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {isLoading ? <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div> : (
          <div className="space-y-2">
            {messages.map((msg: any) => {
              const isMine = msg.sender_id === user?.id;
              return (
                <div key={msg.id} className={cn("flex", isMine ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[75%] rounded-2xl px-4 py-2 text-sm", isMine ? "gradient-primary text-primary-foreground" : "bg-muted")}>
                    <p>{msg.body}</p>
                    <p className={cn("mt-1 text-[10px]", isMine ? "text-primary-foreground/60" : "text-muted-foreground")}>{format(new Date(msg.created_at), "HH:mm")}</p>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="border-t p-3 flex gap-2">
        <Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Type a message..." className="rounded-full border-0 bg-muted/50" />
        <Button type="submit" size="icon" disabled={!message.trim() || sending} className="shrink-0 rounded-full gradient-primary border-0">
          <Send className="h-4 w-4 text-primary-foreground" />
        </Button>
      </form>
    </div>
  );
}
