import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, MessageCircle, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { formatDistanceToNow, differenceInMinutes } from "date-fns";

export default function Messages() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("messages-list")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => {
        queryClient.invalidateQueries({ queryKey: ["conversations"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, queryClient]);

  const { data: friends = [], isLoading } = useQuery({
    queryKey: ["message-friends", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from("friendships")
        .select("*, requester:profiles!friendships_requester_id_fkey(*), addressee:profiles!friendships_addressee_id_fkey(*)")
        .eq("status", "ACCEPTED")
        .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`);
      return (data || []).map((f: any) => ({ friendship: f, friend: f.requester_id === user.id ? f.addressee : f.requester }));
    },
    enabled: !!user,
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from("messages")
        .select("*, sender:profiles!messages_sender_id_fkey(*), receiver:profiles!messages_receiver_id_fkey(*)")
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order("created_at", { ascending: false });
      const convMap = new Map<string, any>();
      (data || []).forEach((msg: any) => {
        const partnerId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
        if (!convMap.has(partnerId)) {
          convMap.set(partnerId, { ...msg, partner: msg.sender_id === user.id ? msg.receiver : msg.sender });
        }
      });
      return Array.from(convMap.values());
    },
    enabled: !!user,
  });

  const conversationPartnerIds = new Set(conversations.map((c: any) => c.partner?.user_id));
  const friendsWithoutConvo = friends.filter((f: any) => !conversationPartnerIds.has(f.friend.user_id));

  const filtered = search.length >= 1
    ? [...conversations.filter((c: any) => c.partner?.display_name?.toLowerCase().includes(search.toLowerCase())),
       ...friendsWithoutConvo.filter((f: any) => f.friend.display_name?.toLowerCase().includes(search.toLowerCase()))]
    : [...conversations, ...friendsWithoutConvo];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <h1 className="mb-4 text-2xl font-bold">Messages</h1>
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search conversations..." className="pl-9 rounded-xl" />
        </div>
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center">
            <MessageCircle className="mx-auto mb-3 h-12 w-12 text-muted-foreground/30" />
            <p className="text-muted-foreground">No conversations yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Add friends to start messaging!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((item: any) => {
              const isConvo = !!item.body;
              const partner = isConvo ? item.partner : item.friend;
              if (!partner) return null;
              const isOnline = partner.last_seen ? differenceInMinutes(new Date(), new Date(partner.last_seen)) < 2 : false;
              return (
                <Link key={partner.user_id} to={`/messages/${partner.user_id}`}>
                  <Card className="border-0 shadow-sm hover:shadow-md transition-all">
                    <CardContent className="flex items-center gap-3 p-3">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={partner.avatar_url || ""} />
                          <AvatarFallback className="gradient-primary text-primary-foreground font-bold">{partner.display_name?.[0]?.toUpperCase()}</AvatarFallback>
                        </Avatar>
                        {isOnline && <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-background bg-green-500" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="truncate font-semibold text-sm">{partner.display_name}</span>
                          {isConvo && <span className="ml-2 shrink-0 text-[11px] text-muted-foreground">{formatDistanceToNow(new Date(item.created_at), { addSuffix: true })}</span>}
                        </div>
                        <p className="truncate text-xs text-muted-foreground">{isConvo ? (item.sender_id === user?.id ? "You: " : "") + item.body : "Start a conversation"}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
