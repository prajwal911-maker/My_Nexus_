import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FriendButton } from "@/components/FriendButton";
import { Loader2, Search } from "lucide-react";
import { Link } from "react-router-dom";

export default function Discover() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["discover-users", search],
    queryFn: async () => {
      let query = supabase.from("profiles").select("*").neq("user_id", user?.id || "").limit(20);
      if (search.length >= 2) query = query.or(`username.ilike.%${search}%,display_name.ilike.%${search}%`);
      const { data } = await query.order("created_at", { ascending: false });
      return data || [];
    },
    enabled: !!user,
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <h1 className="mb-4 text-2xl font-bold">Discover</h1>
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search people..." className="pl-9 rounded-xl" />
        </div>
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
        ) : users.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">No users found</div>
        ) : (
          <div className="space-y-2">
            {users.map((u: any) => (
              <Card key={u.user_id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="flex items-center gap-3 p-3">
                  <Link to={`/profile/${u.username}`}>
                    <Avatar className="h-12 w-12"><AvatarImage src={u.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground font-bold">{u.display_name?.[0]}</AvatarFallback></Avatar>
                  </Link>
                  <div className="min-w-0 flex-1">
                    <Link to={`/profile/${u.username}`} className="block truncate font-semibold text-sm hover:text-primary transition-colors">{u.display_name}</Link>
                    <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                  </div>
                  <FriendButton targetUserId={u.user_id} />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
