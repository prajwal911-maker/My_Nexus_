import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) toast.error(error.message);
    else navigate("/");
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4" style={{ background: "linear-gradient(135deg, hsl(262, 83%, 96%), hsl(330, 81%, 96%), hsl(37, 91%, 96%))" }}>
      <div className="mb-8 flex flex-col items-center animate-fade-in-up">
        <h1 className="text-5xl font-black gradient-text tracking-tight mb-2">NEXUS</h1>
        <p className="text-sm text-muted-foreground">Connect. Share. Inspire.</p>
      </div>

      <Card className="w-full max-w-sm border-0 shadow-lg animate-fade-in-up">
        <CardHeader className="pb-4 text-center">
          <CardTitle className="text-xl">Welcome back</CardTitle>
          <CardDescription>Sign in to your account</CardDescription>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@example.com" className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required placeholder="••••••••" className="rounded-xl" />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button type="submit" className="w-full rounded-xl gradient-primary border-0 h-11 font-semibold" disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
            </Button>
            <div className="flex flex-col items-center gap-2 text-sm">
              <Link to="/signup" className="font-semibold text-primary hover:underline">Create an account</Link>
              <Link to="/forgot-password" className="text-muted-foreground hover:underline">Forgot password?</Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
