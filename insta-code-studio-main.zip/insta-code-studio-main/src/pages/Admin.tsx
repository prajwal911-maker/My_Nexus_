import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Shield, Ban, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function Admin() {
  const { isAdmin } = useAuth();
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
      return data || [];
    },
    enabled: isAdmin,
  });

  const toggleBan = async (userId: string, isBanned: boolean) => {
    await supabase.from("profiles").update({ is_banned: !isBanned }).eq("user_id", userId);
    queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    toast.success(isBanned ? "User unbanned" : "User banned");
  };

  if (!isAdmin) return (
    <div className="min-h-screen bg-background"><Navbar /><p className="py-12 text-center text-muted-foreground">Access denied</p></div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <div className="mb-4 flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Admin Panel</h1>
        </div>

        <Card className="border-0 shadow-sm">
          <CardHeader><CardTitle className="text-lg">Users ({users.length})</CardTitle></CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-4"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
            ) : (
              <div className="space-y-2">
                {users.map((u: any) => (
                  <div key={u.user_id} className="flex items-center gap-3 rounded-xl bg-muted/30 p-3">
                    <Avatar className="h-10 w-10"><AvatarImage src={u.avatar_url || ""} /><AvatarFallback className="gradient-primary text-primary-foreground text-xs font-bold">{u.display_name?.[0]}</AvatarFallback></Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{u.display_name}</p>
                      <p className="truncate text-xs text-muted-foreground">@{u.username} · {u.email}</p>
                    </div>
                    {u.is_banned && <Badge variant="destructive" className="text-[10px]">Banned</Badge>}
                    <Button size="sm" variant={u.is_banned ? "outline" : "destructive"} onClick={() => toggleBan(u.user_id, u.is_banned)} className="rounded-xl gap-1 text-xs">
                      {u.is_banned ? <><CheckCircle className="h-3 w-3" /> Unban</> : <><Ban className="h-3 w-3" /> Ban</>}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      <BottomNav />
    </div>
  );
}
