import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export default function Signup() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (username.length < 3) { toast.error("Username must be at least 3 characters"); return; }
    setLoading(true);

    const { data: existing } = await supabase.from("profiles").select("id").eq("username", username.toLowerCase()).maybeSingle();
    if (existing) { toast.error("Username already taken"); setLoading(false); return; }

    const { error } = await supabase.auth.signUp({
      email, password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { username: username.toLowerCase(), display_name: displayName || username },
      },
    });
    if (error) toast.error(error.message);
    else { toast.success("Account created! Check your email to confirm."); navigate("/login"); }
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 py-8" style={{ background: "linear-gradient(135deg, hsl(262, 83%, 96%), hsl(330, 81%, 96%), hsl(37, 91%, 96%))" }}>
      <div className="mb-8 flex flex-col items-center animate-fade-in-up">
        <h1 className="text-5xl font-black gradient-text tracking-tight mb-2">NEXUS</h1>
        <p className="text-sm text-muted-foreground">Join the community today</p>
      </div>
      <Card className="w-full max-w-sm border-0 shadow-lg animate-fade-in-up">
        <CardHeader className="pb-4 text-center">
          <CardTitle className="text-xl">Create Account</CardTitle>
          <CardDescription>Get started in seconds</CardDescription>
        </CardHeader>
        <form onSubmit={handleSignup}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} maxLength={30} placeholder="johndoe" className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="displayName">Display Name</Label>
              <Input id="displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="John Doe" className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@example.com" className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} placeholder="••••••••" className="rounded-xl" />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button type="submit" className="w-full rounded-xl gradient-primary border-0 h-11 font-semibold" disabled={loading}>
              {loading ? "Creating..." : "Create Account"}
            </Button>
            <Link to="/login" className="text-sm font-semibold text-primary hover:underline">Already have an account? Sign in</Link>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
