import { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { PostCard, PostWithDetails } from "@/components/PostCard";
import { FriendButton } from "@/components/FriendButton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Calendar, Users, Loader2, Camera, FileText } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function Profile() {
  const { username } = useParams<{ username: string }>();
  const { user, profile: myProfile, refreshProfile } = useAuth();
  const queryClient = useQueryClient();
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ display_name: "", bio: "" });
  const [uploading, setUploading] = useState(false);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", username],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("username", username!).single();
      if (error) throw error;
      return data;
    },
    enabled: !!username,
  });

  const { data: friendCount = 0 } = useQuery({
    queryKey: ["friend-count", profile?.user_id],
    queryFn: async () => {
      if (!profile) return 0;
      const { data } = await supabase.rpc("get_friend_count", { _user_id: profile.user_id });
      return data || 0;
    },
    enabled: !!profile,
  });

  const { data: posts = [] } = useQuery({
    queryKey: ["posts", "user", profile?.user_id],
    queryFn: async () => {
      if (!profile) return [];
      const { data } = await supabase
        .from("posts")
        .select(`*, author:profiles!posts_author_id_fkey(*), media(*), likes(user_id), comments(id), shares(id)`)
        .eq("author_id", profile.user_id)
        .order("created_at", { ascending: false });
      return (data || []) as unknown as PostWithDetails[];
    },
    enabled: !!profile,
  });

  const isOwn = user?.id === profile?.user_id;

  const handleEditOpen = () => {
    if (profile) { setEditForm({ display_name: profile.display_name, bio: profile.bio || "" }); setEditOpen(true); }
  };

  const handleEditSave = async () => {
    if (!user) return;
    const { error } = await supabase.from("profiles").update({ display_name: editForm.display_name, bio: editForm.bio }).eq("user_id", user.id);
    if (error) toast.error("Failed to update profile");
    else { toast.success("Profile updated!"); queryClient.invalidateQueries({ queryKey: ["profile", username] }); refreshProfile(); setEditOpen(false); }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `${user.id}/avatar.${ext}`;
    await supabase.storage.from("media").upload(path, file, { upsert: true });
    const { data } = supabase.storage.from("media").getPublicUrl(path);
    await supabase.from("profiles").update({ avatar_url: data.publicUrl }).eq("user_id", user.id);
    queryClient.invalidateQueries({ queryKey: ["profile"] });
    refreshProfile();
    toast.success("Avatar updated!");
    setUploading(false);
  };

  if (isLoading) return (
    <div className="min-h-screen bg-background"><Navbar /><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div></div>
  );

  if (!profile) return (
    <div className="min-h-screen bg-background"><Navbar /><p className="py-12 text-center text-muted-foreground">User not found</p></div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <Card className="mb-6 overflow-hidden border-0 shadow-sm">
          <div className="h-28 gradient-primary sm:h-36" />
          <CardContent className="relative px-5 pb-5">
            <div className="relative -mt-14 mb-3">
              <Avatar className="h-24 w-24 border-4 border-background ring-2 ring-primary/20">
                <AvatarImage src={profile.avatar_url || ""} />
                <AvatarFallback className="gradient-primary text-primary-foreground text-2xl font-bold">{profile.display_name[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              {isOwn && (
                <label className="absolute bottom-0 left-16 cursor-pointer rounded-full gradient-primary p-2 text-primary-foreground shadow-lg transition-transform hover:scale-110">
                  <Camera className="h-3.5 w-3.5" />
                  <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
                </label>
              )}
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h1 className="text-xl font-bold">{profile.display_name}</h1>
                <p className="text-sm text-muted-foreground">@{profile.username}</p>
                {profile.bio && <p className="mt-2 text-sm leading-relaxed">{profile.bio}</p>}
              </div>
              <div className="shrink-0">
                {isOwn ? (
                  <Button variant="outline" size="sm" onClick={handleEditOpen} className="rounded-xl">Edit Profile</Button>
                ) : (
                  <FriendButton targetUserId={profile.user_id} />
                )}
              </div>
            </div>

            <Separator className="my-4" />
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><Users className="h-4 w-4" /><strong className="text-foreground">{friendCount}</strong> friends</span>
              <span className="flex items-center gap-1.5"><FileText className="h-4 w-4" /><strong className="text-foreground">{posts.length}</strong> posts</span>
              <span className="flex items-center gap-1.5"><Calendar className="h-4 w-4" />{format(new Date(profile.created_at), "MMM yyyy")}</span>
            </div>
          </CardContent>
        </Card>

        <h2 className="mb-4 text-lg font-semibold">Posts</h2>
        {posts.length === 0 ? (
          <p className="py-8 text-center text-muted-foreground">No posts yet</p>
        ) : (
          posts.map((post) => <PostCard key={post.id} post={post} />)
        )}

        <Dialog open={editOpen} onOpenChange={setEditOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader><DialogTitle>Edit Profile</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2"><Label>Display Name</Label><Input value={editForm.display_name} onChange={(e) => setEditForm({ ...editForm, display_name: e.target.value })} className="rounded-xl" /></div>
              <div className="space-y-2"><Label>Bio</Label><Textarea value={editForm.bio} onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })} maxLength={200} rows={3} className="rounded-xl" /></div>
            </div>
            <DialogFooter className="flex-col gap-2 sm:flex-row">
              <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-xl">Cancel</Button>
              <Button onClick={handleEditSave} className="rounded-xl gradient-primary border-0">Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
      <BottomNav />
    </div>
  );
}
