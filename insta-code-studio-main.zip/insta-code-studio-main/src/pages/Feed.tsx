import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { PostCard, PostWithDetails } from "@/components/PostCard";
import { PostingRulesBanner } from "@/components/PostingRulesBanner";
import { StoryBar } from "@/components/StoryBar";
import { Button } from "@/components/ui/button";
import { PlusSquare, Loader2, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { useEffect, useCallback, useRef } from "react";

const PAGE_SIZE = 10;

async function fetchPostsPage(pageParam: number): Promise<PostWithDetails[]> {
  const from = pageParam * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  const { data, error } = await supabase
    .from("posts")
    .select(`*, author:profiles!posts_author_id_fkey(*), media(*), likes(user_id), comments(id), shares(id)`)
    .order("created_at", { ascending: false })
    .range(from, to);
  if (error) throw error;
  const posts = (data || []) as unknown as PostWithDetails[];

  const sharedIds = posts.filter(p => p.shared_post_id).map(p => p.shared_post_id!);
  if (sharedIds.length > 0) {
    const { data: sharedPosts } = await supabase
      .from("posts").select(`*, author:profiles!posts_author_id_fkey(*)`).in("id", sharedIds);
    const sharedMap = new Map((sharedPosts || []).map(sp => [sp.id, sp]));
    for (const post of posts) {
      if (post.shared_post_id && sharedMap.has(post.shared_post_id)) {
        post.shared_post = sharedMap.get(post.shared_post_id) as unknown as PostWithDetails;
      }
    }
  }
  return posts;
}

export default function Feed() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const debounceRef = useRef<NodeJS.Timeout>();

  // Debounced realtime invalidation for performance
  const debouncedInvalidate = useCallback(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ["posts"] });
    }, 2000);
  }, [queryClient]);

  useEffect(() => {
    const channel = supabase
      .channel("feed-realtime")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "posts" }, debouncedInvalidate)
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "posts" }, debouncedInvalidate)
      .subscribe();
    return () => { clearTimeout(debounceRef.current); supabase.removeChannel(channel); };
  }, [debouncedInvalidate]);

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, isRefetching } = useInfiniteQuery({
    queryKey: ["posts"],
    queryFn: async ({ pageParam = 0 }) => fetchPostsPage(pageParam),
    getNextPageParam: (lastPage, allPages) => lastPage.length === PAGE_SIZE ? allPages.length : undefined,
    initialPageParam: 0,
  });

  const posts = data?.pages.flat() ?? [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-3 py-4 pb-20 sm:px-4 sm:py-6 md:pb-6">
        <div className="mb-5 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Feed</h1>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => queryClient.invalidateQueries({ queryKey: ["posts"] })} disabled={isRefetching} className="h-9 w-9 rounded-full">
              <RefreshCw className={`h-4 w-4 ${isRefetching ? "animate-spin" : ""}`} />
            </Button>
            {user && (
              <Button asChild size="sm" className="hidden sm:inline-flex gradient-primary border-0 rounded-xl">
                <Link to="/create-post"><PlusSquare className="mr-2 h-4 w-4" /> New Post</Link>
              </Button>
            )}
          </div>
        </div>

        {user && <StoryBar />}
        {user && <PostingRulesBanner />}

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : posts.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-lg font-medium text-muted-foreground">No posts yet</p>
            <p className="mt-1 text-sm text-muted-foreground">Be the first to share something!</p>
          </div>
        ) : (
          <>
            {posts.map((post) => <PostCard key={post.id} post={post} />)}
            {hasNextPage && (
              <div className="flex justify-center py-4">
                <Button variant="outline" onClick={() => fetchNextPage()} disabled={isFetchingNextPage} className="rounded-xl">
                  {isFetchingNextPage ? "Loading..." : "Load more"}
                </Button>
              </div>
            )}
          </>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
