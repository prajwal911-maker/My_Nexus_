export interface SavedAccount {
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  username: string;
}

const STORAGE_KEY = "nexus_saved_accounts";

export function getSavedAccounts(): SavedAccount[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveCurrentAccount(account: SavedAccount) {
  const accounts = getSavedAccounts().filter(a => a.email !== account.email);
  accounts.unshift(account);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts.slice(0, 5)));
}

export function removeAccount(email: string) {
  const accounts = getSavedAccounts().filter(a => a.email !== email);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
}
