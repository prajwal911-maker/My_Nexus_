import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Home, Users, PlusSquare, Shield, LogOut, User, Bell, MessageCircle, Compass } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

export function Navbar() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  const { data: pendingRequests = 0 } = useQuery({
    queryKey: ["pending-request-count", user?.id],
    queryFn: async () => {
      if (!user) return 0;
      const { count } = await supabase
        .from("friendships")
        .select("*", { count: "exact", head: true })
        .eq("addressee_id", user.id)
        .eq("status", "REQUESTED");
      return count || 0;
    },
    enabled: !!user,
    refetchInterval: 30000,
  });

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  const navItems = [
    { to: "/", icon: Home, label: "Feed" },
    { to: "/discover", icon: Compass, label: "Discover" },
    { to: "/friends", icon: Users, label: "Friends", badge: pendingRequests },
    { to: "/messages", icon: MessageCircle, label: "Messages" },
    { to: "/create-post", icon: PlusSquare, label: "Create" },
  ];

  if (!user) return null;

  return (
    <nav className="sticky top-0 z-50 border-b glass">
      <div className="mx-auto flex h-14 max-w-4xl items-center justify-between px-4">
        <Link to="/" className="text-xl font-extrabold gradient-text tracking-tight">
          NEXUS
        </Link>

        <div className="hidden items-center gap-0.5 md:flex">
          {navItems.map((item) => (
            <Button key={item.to} variant="ghost" size="sm" asChild className="relative gap-2 text-muted-foreground hover:text-foreground">
              <Link to={item.to}>
                <item.icon className="h-4 w-4" />
                {item.label}
                {item.badge ? (
                  <Badge className="absolute -right-1 -top-1 h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10px] gradient-primary border-0 text-primary-foreground">
                    {item.badge}
                  </Badge>
                ) : null}
              </Link>
            </Button>
          ))}
          {isAdmin && (
            <Button variant="ghost" size="sm" asChild className="gap-2 text-muted-foreground hover:text-foreground">
              <Link to="/admin"><Shield className="h-4 w-4" /> Admin</Link>
            </Button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {pendingRequests > 0 && (
            <Button variant="ghost" size="icon" className="relative md:hidden" onClick={() => navigate("/friends")}>
              <Bell className="h-5 w-5" />
              <Badge className="absolute -right-1 -top-1 h-4 min-w-4 items-center justify-center rounded-full px-1 text-[10px] gradient-primary border-0 text-primary-foreground">
                {pendingRequests}
              </Badge>
            </Button>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full ring-2 ring-transparent hover:ring-primary/20 transition-all">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={profile?.avatar_url || ""} />
                  <AvatarFallback className="gradient-primary text-primary-foreground text-xs font-bold">
                    {profile?.display_name?.[0]?.toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => navigate(`/profile/${profile?.username}`)}>
                <User className="mr-2 h-4 w-4" /> Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("/messages")}>
                <MessageCircle className="mr-2 h-4 w-4" /> Messages
              </DropdownMenuItem>
              {isAdmin && (
                <DropdownMenuItem onClick={() => navigate("/admin")}>
                  <Shield className="mr-2 h-4 w-4" /> Admin Panel
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                <LogOut className="mr-2 h-4 w-4" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
