import { useState, useCallback, memo } from "react";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, Share2, Trash2, MoreHorizontal, Bookmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CommentSection } from "./CommentSection";
import { ShareDialog } from "./ShareDialog";
import type { Tables } from "@/integrations/supabase/types";
import { cn } from "@/lib/utils";

export interface PostWithDetails {
  id: string;
  caption: string | null;
  created_at: string;
  author_id: string;
  shared_post_id: string | null;
  share_comment: string | null;
  author: Tables<"profiles">;
  media: Tables<"media">[];
  likes: { user_id: string }[];
  comments: { id: string }[];
  shares: { id: string }[];
  shared_post?: PostWithDetails | null;
}

export const PostCard = memo(function PostCard({ post }: { post: PostWithDetails }) {
  const { user, isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [showComments, setShowComments] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [likeAnimating, setLikeAnimating] = useState(false);

  const isLiked = post.likes?.some((l) => l.user_id === user?.id) ?? false;
  const likeCount = post.likes?.length ?? 0;
  const commentCount = post.comments?.length ?? 0;
  const shareCount = post.shares?.length ?? 0;

  const handleLike = useCallback(async () => {
    if (!user) return;
    if (!isLiked) setLikeAnimating(true);
    setTimeout(() => setLikeAnimating(false), 350);
    if (isLiked) {
      await supabase.from("likes").delete().eq("post_id", post.id).eq("user_id", user.id);
    } else {
      await supabase.from("likes").insert({ post_id: post.id, user_id: user.id });
    }
    queryClient.invalidateQueries({ queryKey: ["posts"] });
  }, [user, isLiked, post.id, queryClient]);

  const handleDelete = useCallback(async () => {
    if (!confirm("Delete this post?")) return;
    const { error } = await supabase.from("posts").delete().eq("id", post.id);
    if (error) toast.error("Failed to delete post");
    else {
      toast.success("Post deleted");
      queryClient.invalidateQueries({ queryKey: ["posts"] });
    }
  }, [post.id, queryClient]);

  const canDelete = user?.id === post.author_id || isAdmin;

  return (
    <Card className="mb-4 overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow duration-300 animate-fade-in-up">
      <CardHeader className="flex flex-row items-center gap-3 px-4 pb-2 pt-4">
        <Link to={`/profile/${post.author.username}`}>
          <Avatar className="h-10 w-10 ring-2 ring-primary/10">
            <AvatarImage src={post.author.avatar_url || ""} />
            <AvatarFallback className="gradient-primary text-primary-foreground text-xs font-bold">
              {post.author.display_name[0]?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </Link>
        <div className="min-w-0 flex-1">
          <Link to={`/profile/${post.author.username}`} className="block truncate font-semibold text-sm hover:text-primary transition-colors">
            {post.author.display_name}
          </Link>
          <p className="truncate text-xs text-muted-foreground">
            @{post.author.username} · {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
          </p>
        </div>
        {canDelete && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-muted-foreground">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleDelete} className="text-destructive">
                <Trash2 className="mr-2 h-4 w-4" /> Delete post
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </CardHeader>

      <CardContent className="px-4 pb-2">
        {post.share_comment && <p className="mb-2 text-sm italic text-muted-foreground">"{post.share_comment}"</p>}
        {post.caption && <p className="mb-3 whitespace-pre-wrap text-sm leading-relaxed">{post.caption}</p>}
        {post.media && post.media.length > 0 && (
          <div className={cn("-mx-4 overflow-hidden", post.media.length === 1 ? "" : "grid grid-cols-2 gap-0.5")}>
            {post.media.map((m) =>
              m.type === "VIDEO" ? (
                <video key={m.id} src={m.url} controls className="w-full max-h-[500px] object-cover" />
              ) : (
                <img key={m.id} src={m.url} alt="" className="w-full max-h-[500px] object-cover" loading="lazy" />
              )
            )}
          </div>
        )}
        {post.shared_post && (
          <Card className="mt-3 border bg-muted/30 rounded-xl">
            <CardHeader className="flex flex-row items-center gap-2 p-3 pb-1">
              <Avatar className="h-6 w-6">
                <AvatarImage src={post.shared_post.author?.avatar_url || ""} />
                <AvatarFallback className="text-[10px]">{post.shared_post.author?.display_name?.[0]}</AvatarFallback>
              </Avatar>
              <span className="truncate text-xs font-medium">{post.shared_post.author?.display_name}</span>
            </CardHeader>
            <CardContent className="p-3 pt-1">
              {post.shared_post.caption && <p className="text-xs text-muted-foreground">{post.shared_post.caption}</p>}
            </CardContent>
          </Card>
        )}
      </CardContent>

      <CardFooter className="flex gap-0 border-t px-2 py-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLike}
          className={cn("flex-1 gap-1.5 text-xs transition-all", isLiked ? "text-destructive" : "text-muted-foreground hover:text-destructive")}
        >
          <Heart className={cn("h-4 w-4 transition-all", isLiked && "fill-current", likeAnimating && "animate-like")} />
          {likeCount > 0 && likeCount}
        </Button>
        <Button
          variant="ghost" size="sm"
          onClick={() => setShowComments(!showComments)}
          className="flex-1 gap-1.5 text-xs text-muted-foreground hover:text-primary"
        >
          <MessageCircle className="h-4 w-4" />
          {commentCount > 0 && commentCount}
        </Button>
        <Button
          variant="ghost" size="sm"
          onClick={() => setShowShareDialog(true)}
          className="flex-1 gap-1.5 text-xs text-muted-foreground hover:text-primary"
        >
          <Share2 className="h-4 w-4" />
          {shareCount > 0 && shareCount}
        </Button>
        <Button variant="ghost" size="sm" className="flex-1 gap-1.5 text-xs text-muted-foreground hover:text-primary">
          <Bookmark className="h-4 w-4" />
        </Button>
      </CardFooter>

      {showComments && <CommentSection postId={post.id} />}
      <ShareDialog open={showShareDialog} onOpenChange={setShowShareDialog} postId={post.id} />
    </Card>
  );
});
