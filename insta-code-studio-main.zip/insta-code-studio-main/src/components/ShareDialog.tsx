import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export function ShareDialog({ open, onOpenChange, postId }: { open: boolean; onOpenChange: (v: boolean) => void; postId: string }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [comment, setComment] = useState("");
  const [sharing, setSharing] = useState(false);

  const handleShare = async () => {
    if (!user) return;
    setSharing(true);
    await supabase.from("shares").insert({ post_id: postId, user_id: user.id });
    await supabase.from("posts").insert({
      author_id: user.id,
      shared_post_id: postId,
      share_comment: comment.trim() || null,
    });
    queryClient.invalidateQueries({ queryKey: ["posts"] });
    toast.success("Post shared!");
    setComment("");
    onOpenChange(false);
    setSharing(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Share Post</DialogTitle></DialogHeader>
        <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment..." maxLength={200} rows={3} className="rounded-xl" />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleShare} disabled={sharing} className="gradient-primary border-0">
            {sharing ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sharing...</> : "Share"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
