import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ImagePlus, Music, Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export function CreateStory({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const songRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [songFile, setSongFile] = useState<File | null>(null);
  const [songName, setSongName] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const reset = () => { setFile(null); setPreview(null); setCaption(""); setSongFile(null); setSongName(""); };

  const handleSubmit = async () => {
    if (!user || !file) return;
    setSubmitting(true);
    try {
      const ext = file.name.split(".").pop();
      const mediaPath = `${user.id}/stories/${crypto.randomUUID()}.${ext}`;
      const { error: uploadErr } = await supabase.storage.from("media").upload(mediaPath, file);
      if (uploadErr) throw uploadErr;
      const { data: mediaUrl } = supabase.storage.from("media").getPublicUrl(mediaPath);

      let songUrl: string | null = null;
      if (songFile) {
        const songExt = songFile.name.split(".").pop();
        const songPath = `${user.id}/stories/songs/${crypto.randomUUID()}.${songExt}`;
        const { error: songErr } = await supabase.storage.from("media").upload(songPath, songFile);
        if (!songErr) {
          const { data: sUrl } = supabase.storage.from("media").getPublicUrl(songPath);
          songUrl = sUrl.publicUrl;
        }
      }

      const isVideo = file.type.startsWith("video/");
      await supabase.from("stories").insert({
        author_id: user.id,
        media_url: mediaUrl.publicUrl,
        media_type: isVideo ? "VIDEO" : "IMAGE",
        caption: caption.trim() || null,
        song_name: songName.trim() || null,
        song_url: songUrl,
      });
      toast.success("Story added!");
      queryClient.invalidateQueries({ queryKey: ["stories"] });
      reset();
      onOpenChange(false);
    } catch {
      toast.error("Failed to create story");
    }
    setSubmitting(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) reset(); onOpenChange(v); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Add Story</DialogTitle></DialogHeader>
        <div className="space-y-4">
          {preview ? (
            <div className="relative mx-auto max-w-xs">
              {file?.type.startsWith("video/") ? (
                <video src={preview} className="max-h-64 w-full rounded-xl object-cover" controls />
              ) : (
                <img src={preview} alt="" className="max-h-64 w-full rounded-xl object-cover" />
              )}
              <Button type="button" variant="destructive" size="icon" className="absolute right-2 top-2 h-7 w-7 rounded-full" onClick={() => { setFile(null); setPreview(null); }}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          ) : (
            <button onClick={() => fileRef.current?.click()} className="flex h-40 w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-muted-foreground/20 bg-muted/30 text-muted-foreground transition-all hover:border-primary/40 hover:bg-accent/50">
              <ImagePlus className="h-8 w-8" />
              <span className="text-sm">Tap to add photo or video</span>
            </button>
          )}
          <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleFileChange} />
          <div className="space-y-2">
            <Label>Caption</Label>
            <Input value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Add a caption..." maxLength={200} className="rounded-xl" />
          </div>
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5"><Music className="h-4 w-4" /> Music</Label>
            {songFile ? (
              <div className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2">
                <Music className="h-4 w-4 shrink-0 text-primary" />
                <span className="flex-1 truncate text-sm">{songName}</span>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setSongFile(null); setSongName(""); }}><X className="h-3 w-3" /></Button>
              </div>
            ) : (
              <Button variant="outline" size="sm" onClick={() => songRef.current?.click()} className="w-full rounded-xl"><Music className="mr-2 h-4 w-4" /> Choose audio</Button>
            )}
            <input ref={songRef} type="file" accept="audio/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) { setSongFile(f); setSongName(f.name.replace(/\.[^.]+$/, "")); } }} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!file || submitting} className="gradient-primary border-0">
            {submitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Posting...</> : "Share Story"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
