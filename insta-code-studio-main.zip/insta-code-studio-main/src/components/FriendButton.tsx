import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { UserPlus, UserCheck, Clock, UserX } from "lucide-react";

export function FriendButton({ targetUserId }: { targetUserId: string }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);

  const { data: friendship } = useQuery({
    queryKey: ["friendship", user?.id, targetUserId],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase
        .from("friendships")
        .select("*")
        .or(`and(requester_id.eq.${user.id},addressee_id.eq.${targetUserId}),and(requester_id.eq.${targetUserId},addressee_id.eq.${user.id})`)
        .maybeSingle();
      return data;
    },
    enabled: !!user && user.id !== targetUserId,
  });

  if (!user || user.id === targetUserId) return null;

  const handleAction = async (action: string) => {
    setLoading(true);
    try {
      if (action === "add") {
        await supabase.from("friendships").insert({ requester_id: user.id, addressee_id: targetUserId });
        toast.success("Friend request sent!");
      } else if (action === "accept" && friendship) {
        await supabase.from("friendships").update({ status: "ACCEPTED" }).eq("id", friendship.id);
        toast.success("Friend request accepted!");
      } else if (action === "remove" && friendship) {
        await supabase.from("friendships").delete().eq("id", friendship.id);
        toast.success("Removed");
      }
      queryClient.invalidateQueries({ queryKey: ["friendship"] });
      queryClient.invalidateQueries({ queryKey: ["pending-request-count"] });
    } catch {
      toast.error("Action failed");
    }
    setLoading(false);
  };

  if (!friendship) {
    return (
      <Button size="sm" onClick={() => handleAction("add")} disabled={loading} className="gradient-primary border-0 gap-1.5">
        <UserPlus className="h-4 w-4" /> Add Friend
      </Button>
    );
  }

  if (friendship.status === "ACCEPTED") {
    return (
      <Button size="sm" variant="outline" onClick={() => handleAction("remove")} disabled={loading} className="gap-1.5">
        <UserCheck className="h-4 w-4 text-primary" /> Friends
      </Button>
    );
  }

  if (friendship.status === "REQUESTED") {
    if (friendship.requester_id === user.id) {
      return (
        <Button size="sm" variant="outline" onClick={() => handleAction("remove")} disabled={loading} className="gap-1.5 text-muted-foreground">
          <Clock className="h-4 w-4" /> Pending
        </Button>
      );
    }
    return (
      <div className="flex gap-2">
        <Button size="sm" onClick={() => handleAction("accept")} disabled={loading} className="gradient-primary border-0 gap-1.5">
          <UserCheck className="h-4 w-4" /> Accept
        </Button>
        <Button size="sm" variant="outline" onClick={() => handleAction("remove")} disabled={loading}>
          <UserX className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <Button size="sm" onClick={() => handleAction("add")} disabled={loading} className="gradient-primary border-0 gap-1.5">
      <UserPlus className="h-4 w-4" /> Add Friend
    </Button>
  );
}
