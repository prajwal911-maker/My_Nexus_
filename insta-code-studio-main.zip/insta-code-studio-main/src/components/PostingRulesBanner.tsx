import { usePostingStatus } from "@/hooks/use-posting-status";
import { Users, Info } from "lucide-react";
import { Link } from "react-router-dom";

export function PostingRulesBanner() {
  const { data: status } = usePostingStatus();
  if (!status || status.max_per_day > 10) return null;

  return (
    <div className="mb-4 flex items-start gap-3 rounded-2xl border border-primary/10 bg-accent/50 p-4 text-sm animate-fade-in-up">
      <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
      <div>
        {status.friend_count === 0 ? (
          <p>
            <Link to="/discover" className="font-semibold text-primary hover:underline">Add friends</Link>{" "}
            to start posting! <Users className="inline h-3.5 w-3.5" />
          </p>
        ) : (
          <p>
            You can post <strong>{status.remaining}</strong> more time{status.remaining !== 1 ? "s" : ""} today.
            {status.friend_count <= 10 && " Add more friends to unlock unlimited posts!"}
          </p>
        )}
      </div>
    </div>
  );
}
