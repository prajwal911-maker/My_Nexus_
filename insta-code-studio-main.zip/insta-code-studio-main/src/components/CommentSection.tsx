import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { Link } from "react-router-dom";

export function CommentSection({ postId }: { postId: string }) {
  const { user, isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [body, setBody] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const { data: comments = [] } = useQuery({
    queryKey: ["comments", postId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("comments")
        .select("*, author:profiles!comments_author_id_fkey(*)")
        .eq("post_id", postId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim() || !user) return;
    setSubmitting(true);
    const { error } = await supabase.from("comments").insert({
      post_id: postId,
      author_id: user.id,
      body: body.trim(),
    });
    if (error) toast.error("Failed to post comment");
    else {
      setBody("");
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
      queryClient.invalidateQueries({ queryKey: ["posts"] });
    }
    setSubmitting(false);
  };

  const handleDelete = async (commentId: string) => {
    await supabase.from("comments").delete().eq("id", commentId);
    queryClient.invalidateQueries({ queryKey: ["comments", postId] });
    queryClient.invalidateQueries({ queryKey: ["posts"] });
  };

  return (
    <div className="border-t px-4 py-3">
      <div className="max-h-60 space-y-3 overflow-y-auto">
        {comments.map((comment: any) => (
          <div key={comment.id} className="flex gap-2 animate-fade-in-up">
            <Link to={`/profile/${comment.author?.username}`}>
              <Avatar className="h-7 w-7 shrink-0">
                <AvatarImage src={comment.author?.avatar_url || ""} />
                <AvatarFallback className="text-[10px] gradient-primary text-primary-foreground">{comment.author?.display_name?.[0]}</AvatarFallback>
              </Avatar>
            </Link>
            <div className="min-w-0 flex-1 rounded-2xl bg-muted/50 px-3 py-2">
              <p className="text-xs">
                <Link to={`/profile/${comment.author?.username}`} className="font-semibold hover:text-primary transition-colors">
                  {comment.author?.display_name}
                </Link>{" "}
                <span className="text-muted-foreground">
                  {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
                </span>
              </p>
              <p className="text-sm mt-0.5">{comment.body}</p>
            </div>
            {(user?.id === comment.author_id || isAdmin) && (
              <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive" onClick={() => handleDelete(comment.id)}>
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="mt-3 flex gap-2">
        <Input
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Add a comment..."
          maxLength={1000}
          className="rounded-full bg-muted/50 border-0 focus-visible:ring-primary/30"
        />
        <Button type="submit" size="icon" disabled={!body.trim() || submitting} className="shrink-0 rounded-full gradient-primary border-0">
          <Send className="h-4 w-4 text-primary-foreground" />
        </Button>
      </form>
    </div>
  );
}
