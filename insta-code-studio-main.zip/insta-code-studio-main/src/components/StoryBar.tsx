import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus } from "lucide-react";
import { useState } from "react";
import { CreateStory } from "./CreateStory";
import { StoryViewer } from "./StoryViewer";

interface StoryGroup {
  user_id: string;
  display_name: string;
  avatar_url: string | null;
  stories: any[];
}

export function StoryBar() {
  const { user } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const [viewingGroup, setViewingGroup] = useState<StoryGroup | null>(null);

  const { data: storyGroups = [] } = useQuery({
    queryKey: ["stories"],
    queryFn: async () => {
      const { data } = await supabase
        .from("stories")
        .select("*, author:profiles!stories_author_id_fkey(*)")
        .gt("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false });

      const groups = new Map<string, StoryGroup>();
      (data || []).forEach((s: any) => {
        const uid = s.author_id;
        if (!groups.has(uid)) {
          groups.set(uid, {
            user_id: uid,
            display_name: s.author.display_name,
            avatar_url: s.author.avatar_url,
            stories: [],
          });
        }
        groups.get(uid)!.stories.push(s);
      });
      return Array.from(groups.values());
    },
    refetchInterval: 60000,
  });

  return (
    <>
      <div className="mb-5 flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {/* Add story */}
        <button onClick={() => setCreateOpen(true)} className="flex shrink-0 flex-col items-center gap-1.5">
          <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-primary/30 bg-accent/50 transition-colors hover:border-primary/60">
            <Plus className="h-6 w-6 text-primary" />
          </div>
          <span className="text-[11px] font-medium text-muted-foreground">Your story</span>
        </button>
        {storyGroups.map((group) => (
          <button key={group.user_id} onClick={() => setViewingGroup(group)} className="flex shrink-0 flex-col items-center gap-1.5">
            <div className="rounded-full p-0.5 gradient-accent">
              <Avatar className="h-[60px] w-[60px] border-2 border-background">
                <AvatarImage src={group.avatar_url || ""} />
                <AvatarFallback className="gradient-primary text-primary-foreground font-bold">
                  {group.display_name[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
            <span className="max-w-[64px] truncate text-[11px] font-medium">
              {group.user_id === user?.id ? "You" : group.display_name.split(" ")[0]}
            </span>
          </button>
        ))}
      </div>
      <CreateStory open={createOpen} onOpenChange={setCreateOpen} />
      {viewingGroup && <StoryViewer group={viewingGroup} onClose={() => setViewingGroup(null)} />}
    </>
  );
}
