import { Link, useLocation } from "react-router-dom";
import { Home, Compass, PlusSquare, MessageCircle, User } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const { user, profile } = useAuth();
  const location = useLocation();

  if (!user) return null;

  const items = [
    { to: "/", icon: Home, label: "Home" },
    { to: "/discover", icon: Compass, label: "Discover" },
    { to: "/create-post", icon: PlusSquare, label: "Post", special: true },
    { to: "/messages", icon: MessageCircle, label: "Chat" },
    { to: `/profile/${profile?.username}`, icon: User, label: "Me" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t glass md:hidden">
      <div className="flex h-16 items-center justify-around px-2">
        {items.map((item) => {
          const isActive = item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to);
          return (
            <Link
              key={item.label}
              to={item.to}
              className={cn(
                "flex flex-col items-center gap-0.5 px-3 py-1.5 transition-all duration-200",
                item.special && "relative",
                isActive ? "text-primary" : "text-muted-foreground"
              )}
            >
              {item.special ? (
                <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-glow">
                  <item.icon className="h-5 w-5 text-primary-foreground" />
                </div>
              ) : (
                <>
                  <item.icon className={cn("h-5 w-5 transition-transform", isActive && "scale-110")} />
                  <span className="text-[10px] font-medium">{item.label}</span>
                </>
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
