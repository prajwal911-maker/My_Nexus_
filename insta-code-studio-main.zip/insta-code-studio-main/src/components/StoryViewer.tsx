import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { X, ChevronLeft, ChevronRight, Music, Pause, Play } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface StoryGroup {
  user_id: string;
  display_name: string;
  avatar_url: string | null;
  stories: any[];
}

export function StoryViewer({ group, onClose }: { group: StoryGroup; onClose: () => void }) {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const story = group.stories[currentIndex];
  const duration = story?.media_type === "VIDEO" ? 15000 : 5000;

  useEffect(() => {
    if (!story || !user || user.id === group.user_id) return;
    supabase.from("story_views").upsert({ story_id: story.id, viewer_id: user.id }, { onConflict: "story_id,viewer_id" }).then();
  }, [story?.id, user, group.user_id]);

  useEffect(() => {
    if (story?.song_url) {
      const audio = new Audio(story.song_url);
      audio.volume = 0.5;
      audio.play().catch(() => {});
      audioRef.current = audio;
      return () => { audio.pause(); audio.src = ""; };
    }
  }, [story?.song_url]);

  useEffect(() => {
    if (paused) return;
    setProgress(0);
    const interval = 50;
    const timer = setInterval(() => {
      setProgress(prev => {
        const next = prev + (interval / duration) * 100;
        if (next >= 100) {
          clearInterval(timer);
          if (currentIndex < group.stories.length - 1) setCurrentIndex(i => i + 1);
          else onClose();
          return 0;
        }
        return next;
      });
    }, interval);
    return () => clearInterval(timer);
  }, [currentIndex, paused, duration, group.stories.length, onClose]);

  const goNext = useCallback(() => {
    if (currentIndex < group.stories.length - 1) setCurrentIndex(i => i + 1);
    else onClose();
  }, [currentIndex, group.stories.length, onClose]);

  const goPrev = useCallback(() => {
    if (currentIndex > 0) setCurrentIndex(i => i - 1);
  }, [currentIndex]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") goNext();
      else if (e.key === "ArrowLeft") goPrev();
      else if (e.key === "Escape") onClose();
      else if (e.key === " ") { e.preventDefault(); setPaused(p => !p); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [goNext, goPrev, onClose]);

  if (!story) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95">
      <div className="absolute left-0 right-0 top-0 z-10 flex gap-1 p-3">
        {group.stories.map((_: any, i: number) => (
          <div key={i} className="h-0.5 flex-1 overflow-hidden rounded-full bg-white/20">
            <div className="h-full rounded-full bg-white transition-all duration-75" style={{ width: i < currentIndex ? "100%" : i === currentIndex ? `${progress}%` : "0%" }} />
          </div>
        ))}
      </div>

      <div className="absolute left-0 right-0 top-6 z-10 flex items-center justify-between px-4 pt-2">
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 border border-white/20">
            <AvatarImage src={group.avatar_url || ""} />
            <AvatarFallback className="text-xs text-white">{group.display_name[0]}</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-semibold text-white">{group.display_name}</p>
            <p className="text-[10px] text-white/60">{formatDistanceToNow(new Date(story.created_at), { addSuffix: true })}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setPaused(p => !p)} className="text-white/80 hover:text-white">
            {paused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
          </button>
          <button onClick={onClose} className="text-white/80 hover:text-white"><X className="h-6 w-6" /></button>
        </div>
      </div>

      <div className="relative h-full w-full max-h-[80vh] max-w-md">
        {story.media_type === "VIDEO" ? (
          <video src={story.media_url} className="h-full w-full object-contain" autoPlay muted={false} />
        ) : (
          <img src={story.media_url} alt="" className="h-full w-full object-contain" />
        )}
      </div>

      {story.caption && (
        <div className="absolute bottom-16 left-0 right-0 z-10 px-6 text-center">
          <p className="rounded-2xl bg-black/40 px-4 py-2 text-sm text-white backdrop-blur-sm">{story.caption}</p>
        </div>
      )}

      {story.song_name && (
        <div className="absolute bottom-8 left-0 right-0 z-10 flex items-center justify-center gap-2">
          <Music className="h-3.5 w-3.5 text-white/70" />
          <span className="text-xs text-white/70">{story.song_name}</span>
        </div>
      )}

      <button onClick={goPrev} className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/20 p-1 text-white/60 hover:text-white"><ChevronLeft className="h-6 w-6" /></button>
      <button onClick={goNext} className="absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/20 p-1 text-white/60 hover:text-white"><ChevronRight className="h-6 w-6" /></button>
    </div>
  );
}
