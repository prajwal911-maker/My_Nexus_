import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface PostingStatus {
  allowed: boolean;
  remaining: number;
  max_per_day: number;
  friend_count: number;
  daily_posts: number;
}

export function usePostingStatus() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["posting-status", user?.id],
    queryFn: async (): Promise<PostingStatus> => {
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase.rpc("can_user_post", { _user_id: user.id });
      if (error) throw error;
      return data as unknown as PostingStatus;
    },
    enabled: !!user,
    staleTime: 30000,
  });
}
